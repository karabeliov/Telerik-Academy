﻿namespace Processing_JSON_in_.NET_Homework
{
    public interface IVideo
    {
        string Title { get; set; }
    }
}