﻿namespace ConvertTextToXml
{
    public class Person
    {
        public string Name { get; set; }
        public string City { get; set; }
        public string PhoneNumber { get; set; }
    }
}